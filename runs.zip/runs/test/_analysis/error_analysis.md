# Error analysis of the six main test-set runs

Scorer v2. `build/error_analysis.py`; `methodology/analysis-protocol.md` §16. Every number here is descriptive and outside the claim family of 12.

## 1. Outcomes per 1,000 diagrams

| Run | compile fail | of which no `@enduml` (C2) | `finish_reason` length | low-structural | El only / Rel only / both | ok | failures |
|---|---|---|---|---|---|---|---|
| `2B_zero_shot` | 809 | 359 | 357 | 95 | 4 / 80 / 11 | 96 | 904 |
| `2B_20000` | 97 | 54 | 54 | 67 | 3 / 54 / 10 | 836 | 164 |
| `9B_zero_shot` | 589 | 179 | 179 | 188 | 10 / 165 / 13 | 223 | 777 |
| `9B_20000` | 70 | 21 | 21 | 37 | 2 / 28 / 7 | 893 | 107 |
| `27B_zero_shot` | 356 | 92 | 89 | 114 | 7 / 99 / 8 | 530 | 470 |
| `27B_20000` | 43 | 11 | 11 | 31 | 1 / 24 / 6 | 926 | 74 |

Provider drop (R) is 0, 0, 0, 0, 0, 0 per 1,000 in the six runs.

Shares of each run's own failures (not of the 1,000 diagrams):

| Run | compile fail | no `@enduml` | `finish_reason` length | low-structural | El only | Rel only | both |
|---|---|---|---|---|---|---|---|
| `2B_zero_shot` | 0.895 | 0.397 | 0.395 | 0.105 | 0.004 | 0.088 | 0.012 |
| `2B_20000` | 0.592 | 0.329 | 0.329 | 0.408 | 0.018 | 0.329 | 0.061 |
| `9B_zero_shot` | 0.758 | 0.230 | 0.230 | 0.242 | 0.013 | 0.212 | 0.017 |
| `9B_20000` | 0.654 | 0.196 | 0.196 | 0.346 | 0.019 | 0.262 | 0.065 |
| `27B_zero_shot` | 0.757 | 0.196 | 0.189 | 0.243 | 0.015 | 0.211 | 0.017 |
| `27B_20000` | 0.581 | 0.149 | 0.149 | 0.419 | 0.013 | 0.324 | 0.081 |


## 2. Transitions, zero-shot class → fine-tuned class (diagrams)

**2B**

| zero-shot \ fine-tuned | drop | compile fail | low | ok |
|---|---|---|---|---|
| drop | 0 | 0 | 0 | 0 |
| compile fail | 0 | 89 | 64 | 656 |
| low | 0 | 5 | 3 | 87 |
| ok | 0 | 3 | 0 | 93 |

**9B**

| zero-shot \ fine-tuned | drop | compile fail | low | ok |
|---|---|---|---|---|
| drop | 0 | 0 | 0 | 0 |
| compile fail | 0 | 45 | 22 | 522 |
| low | 0 | 15 | 11 | 162 |
| ok | 0 | 10 | 4 | 209 |

**27B**

| zero-shot \ fine-tuned | drop | compile fail | low | ok |
|---|---|---|---|---|
| drop | 0 | 0 | 0 | 0 |
| compile fail | 0 | 17 | 16 | 323 |
| low | 0 | 8 | 11 | 95 |
| ok | 0 | 18 | 4 | 508 |

## 3. Relation agreement on endpoint-matched edges

Ground-truth edges endpoint-matched in both runs of a size, on the diagrams both compiled; note links left out. Share whose answer relation equals the ground truth's. Interval: paired bootstrap, 95%, only with at least 100 edges in 30 diagrams. A realization arrow counts as inheritance; a dotted line with no head counts as dependency; message arrow styles are not distinguished.

| Size | Relation | edges / diagrams | zero-shot | fine-tuned | Δ [95% CI] | orientation zs / ft |
|---|---|---|---|---|---|---|
| 2B | inheritance | 89 / 39 | 0.461 | 0.989 | 0.528 (point) | 0.951 / 0.989 |
| 2B | composition | 19 / 12 | 0.053 | 0.895 | 0.842 (point) | 0.000 / 1.000 |
| 2B | aggregation | 12 / 8 | 0.083 | 1.000 | 0.917 (point) | 1.000 / 1.000 |
| 2B | dependency | 24 / 10 | 0.167 | 1.000 | 0.833 (point) | 1.000 / 1.000 |
| 2B | association | 66 / 28 | 0.606 | 0.985 | 0.379 (point) | 0.425 / 1.000 |
| 2B | message (family agreement) | 541 / 80 | 0.924 | 1.000 | +0.076 [+0.020, +0.142] | 0.902 / 0.998 |
| 9B | inheritance | 443 / 151 | 0.722 | 0.984 | +0.262 [+0.173, +0.352] | 0.816 / 0.995 |
| 9B | composition | 116 / 42 | 0.345 | 0.983 | +0.638 [+0.475, +0.791] | 0.600 / 0.982 |
| 9B | aggregation | 97 / 53 | 0.381 | 0.969 | 0.588 (point) | 0.649 / 0.989 |
| 9B | dependency | 98 / 31 | 0.755 | 0.969 | 0.214 (point) | 1.000 / 0.968 |
| 9B | association | 264 / 97 | 0.769 | 0.920 | +0.152 [+0.037, +0.267] | 0.828 / 0.988 |
| 9B | message (family agreement) | 731 / 85 | 0.741 | 1.000 | +0.259 [+0.165, +0.363] | 0.956 / 0.996 |
| 27B | inheritance | 587 / 179 | 0.928 | 0.986 | +0.058 [+0.023, +0.105] | 0.949 / 0.997 |
| 27B | composition | 111 / 47 | 0.748 | 0.991 | +0.243 [+0.067, +0.435] | 0.807 / 0.991 |
| 27B | aggregation | 146 / 68 | 0.726 | 0.973 | +0.247 [+0.119, +0.393] | 0.783 / 1.000 |
| 27B | dependency | 160 / 46 | 0.931 | 0.988 | +0.056 [-0.021, +0.158] | 0.993 / 1.000 |
| 27B | association | 377 / 131 | 0.825 | 0.934 | +0.109 [-0.004, +0.215] | 0.801 / 0.977 |
| 27B | message (family agreement) | 2447 / 236 | 0.944 | 0.999 | +0.055 [+0.032, +0.086] | 0.972 / 0.999 |

11 intervals on Δ, uncorrected, none in the claim family. Orientation: the share of agreeing edges with the same canonical source and target (association: the same arrowhead class).

### Ground truth → answer relation, paired edges

- 2B zs: aggregation->aggregation 1, aggregation->association 1, aggregation->composition 2, aggregation->dependency 5, aggregation->inheritance 2, aggregation->message 1, association->association 40, association->dependency 24, association->inheritance 1, association->message 1, composition->association 2, composition->composition 1, composition->dependency 12, composition->inheritance 3, composition->message 1, dependency->association 18, dependency->dependency 4, dependency->inheritance 1, dependency->message 1, inheritance->association 29, inheritance->dependency 18, inheritance->inheritance 41, inheritance->message 1, message->association 19, message->dependency 22, message->message 500
- 2B ft: aggregation->aggregation 12, association->association 65, association->inheritance 1, composition->association 2, composition->composition 17, dependency->dependency 24, inheritance->association 1, inheritance->inheritance 88, message->message 541
- 9B zs: aggregation->aggregation 37, aggregation->association 29, aggregation->composition 5, aggregation->dependency 11, aggregation->inheritance 15, association->aggregation 7, association->association 203, association->dependency 17, association->inheritance 37, composition->aggregation 4, composition->association 35, composition->composition 40, composition->dependency 12, composition->inheritance 25, dependency->association 6, dependency->dependency 74, dependency->inheritance 18, inheritance->association 61, inheritance->dependency 62, inheritance->inheritance 320, message->association 168, message->dependency 21, message->message 542
- 9B ft: aggregation->aggregation 94, aggregation->composition 3, association->aggregation 14, association->association 243, association->composition 1, association->dependency 2, association->message 4, composition->aggregation 2, composition->composition 114, dependency->association 1, dependency->dependency 95, dependency->inheritance 2, inheritance->association 6, inheritance->dependency 1, inheritance->inheritance 436, message->message 731
- 27B zs: aggregation->aggregation 106, aggregation->association 17, aggregation->composition 19, aggregation->inheritance 4, association->aggregation 12, association->association 311, association->composition 5, association->dependency 12, association->inheritance 37, composition->aggregation 4, composition->association 23, composition->composition 83, composition->inheritance 1, dependency->association 8, dependency->dependency 149, dependency->inheritance 3, inheritance->association 10, inheritance->composition 1, inheritance->dependency 31, inheritance->inheritance 545, message->association 133, message->dependency 4, message->message 2310
- 27B ft: aggregation->aggregation 142, aggregation->association 4, association->aggregation 4, association->association 352, association->dependency 1, association->inheritance 11, association->message 9, composition->association 1, composition->composition 110, dependency->dependency 158, dependency->message 2, inheritance->dependency 8, inheritance->inheritance 579, message->association 1, message->dependency 1, message->message 2445

## 4. The hand-coded sample

95 cases, one per run × type × tier × failure class. Coded blind in two independent passes (pass 1: 95, pass 2: 95).
Coders: pass 1 language-model coder Claude Opus 5.5 (claude-opus-5-5), four batches; pass 2 language-model coder Claude Opus 5.5 (claude-opus-5-5), four batches, independent of pass 1; disagreements and flagged cases: the author (2026-10-29).

| Condition | cases | agree | raw | κ |
|---|---|---|---|---|
| zero_shot | 48 | 47 | 0.979 | 0.975 |
| fine_tuned | 47 | 43 | 0.915 | 0.893 |
| all | 95 | 90 | 0.947 | 0.937 |

To the author: 12 cases; unresolved: 0.

Sample primary codes per run (counts in the sample, not rates):

| Run | R | C1 | C2 | C3 | S1 | S2 | S3 | S4 | S5 | S6 | S7 | M |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `2B_zero_shot` | 0 | 2 | 3 | 5 | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| `2B_20000` | 0 | 4 | 4 | 0 | 1 | 2 | 0 | 5 | 0 | 0 | 0 | 0 |
| `9B_zero_shot` | 0 | 2 | 5 | 4 | 2 | 0 | 2 | 1 | 0 | 0 | 0 | 0 |
| `9B_20000` | 0 | 6 | 2 | 2 | 2 | 0 | 0 | 3 | 0 | 0 | 0 | 0 |
| `27B_zero_shot` | 0 | 5 | 2 | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 1 | 0 |
| `27B_20000` | 0 | 5 | 3 | 2 | 1 | 1 | 0 | 2 | 0 | 0 | 1 | 1 |

Separability of the conditions on the displayed (stripped) answers, all failure cells: balanced accuracy of the best rule "zero-shot if any of A and none of B" over a fixed cue list, in sample.

- 2B: 0.693 (zero-shot if any of ['note', 'alias', 'noend'] and none of ['direction_arrow', 'long']; 904 zero-shot, 164 fine-tuned cells)
- 9B: 0.721 (zero-shot if any of ['quoted', 'noend'] and none of ['direction_arrow']; 777 zero-shot, 107 fine-tuned cells)
- 27B: 0.738 (zero-shot if any of ['alias', 'noend'] and none of ['direction_arrow', 'long']; 470 zero-shot, 74 fine-tuned cells)

## 5. Description

Written after the coding (2026-10-29), from the final codes and the coders' evidence lines. The
sample has one case per run × type × tier × failure class, so its counts (in brackets, cases of
the run's sample) describe the kinds of failure, not how often each occurs; the rates are §1's.

**2B.** Before fine-tuning (16 cases), the sampled failures are mostly the wrong diagram family
(C3, 5). Sequence diagrams are written with class-diagram arrows (`P ..> C : …`) or `interface`
lifelines, and a class diagram with bare arrows renders as a sequence. Then come runaway answers
(C2, 3) that repeat display-only lines until the token limit, syntax errors (C1, 2), missed and
invented relations (S2, 2; S3, 2), one misread name (S4) and one relation-type error (S1, plain
links drawn as `..>`). After fine-tuning (16), misread names lead (S4, 5): `did:....:GS1` with four
dots for three, `EmploysManagement` for `Employes…`, a dropped word, a package subtitle glued onto
the class name. Each one fails every edge that touches the name. Runaway answers (C2, 4) and syntax
errors (C1, 4) follow: a name with parentheses or spaces left unquoted, `activate` after
`deactivate` with no message between. No sampled case is a family confusion.

**9B.** Before fine-tuning (16), runaway answers (C2, 5) and family confusion (C3, 4) lead, with
lifelines written as `rectangle` or the diagram redrawn as packages of components. Relation-type
errors (S1, 2) are plain associations drawn as inheritance and diamonds on the part's side. After
fine-tuning (15), syntax errors lead (C1, 6), each one token on otherwise faithful content: an
unquoted `Foo3()`, `ms-trade` or `mongoose.model()`, a note block closed with `endrnote`, a note
opened before its class. Misread names follow (S4, 3): `Appellant` for `Appelant`, a dropped first
line of a two-line name, a missing space after `:`. Family confusion remains in a new form (C3,
2): class diagrams written as bare `A -> B` lines with no declarations render as sequences.
Relation-type errors (S1, 2) are associations drawn as aggregation (`o->`) and composition for
aggregation.

**27B.** Before fine-tuning (16), syntax errors (C1, 5) and family confusion (C3, 4) lead. The
syntax errors include empty packages without `{}`, an edge ending in a colon, and an invalid
`skinparam` block. The family confusions are participants written as `component` or `partition`,
and a sequence redrawn as a class diagram. Relation-type errors (S1, 2) are aggregation written as
composition and associations as inheritance. After fine-tuning (16), syntax errors still lead (C1,
5): unquoted generics (`DomainRepository<I, T>`), `rnote … endrnote`, `hide empty namespace`, a
`database` without its body. Runaway answers (C2, 3) still occur, looping on a repeated block or
on display-only lines. Family confusion (C3, 2) is the same bare-arrow and class-arrow form as at
the 9B. The rest are misread names (S4, 2), one association drawn as aggregation (S1), one missing
class (S7), one set of package links attached to the classes inside (S2) and one measurement
artifact (M).

**Across sizes.** The zero-shot failures sampled are broken generation (C2) and the wrong diagram
family (C3): 10 and 13 of 48 cases. After fine-tuning they are mostly one syntax slip on faithful
content (C1, 15 of 47) or a misread name (S4, 10 of 47). Runaway answers remain at every size
(9 of 47).

**Relation agreement (§3).**
- On the edges both runs connected, the share drawn with the right relation rises at every size
  and for every relation.
- The rises are largest at the 2B (composition 0.05 → 0.89, aggregation 0.08 → 1.00, dependency
  0.17 → 1.00), where every class relation is below the floor and has points only.
- Among the rows with intervals, composition and aggregation rise most: at the 9B composition 0.34
  → 0.98; at the 27B composition 0.75 → 0.99 and aggregation 0.73 → 0.97. The 9B's aggregation
  (0.38 → 0.97) is points only.
- The intervals of the 27B's dependency and association rows include 0.
- After fine-tuning, every class relation agrees on at least 0.89 of its edges, and orientation
  on the agreeing edges is at least 0.96.
- Zero-shot, the 2B draws 8% and the 9B 26% of the sequence messages as associations or
  dependencies (message agreement 0.92 and 0.74); after fine-tuning none at either size (1.00).

**Separability.** On the stripped answers, a simple rule still guesses the condition with 0.69–0.74
balanced accuracy, mostly from a missing `@enduml` and from directional arrows (`-up-`). The
coders saw the stripped answers, so their blinding was partial.

**Measurement.** One case is a measurement artifact (M). It is a 27B fine-tuned answer whose input
image (key `de434622c1f4…`) is rendered on a black background, so the ground truth's black arrows
and labels do not show. Two other test images have the same defect (Limitations).

## Limitations

- Key `7b907a2193a6…`: the ground truth declares `Either --> "type" Either.SideType`, which its image does not draw.
- Keys `de434622c1f4…`, `73ece5e02bc2…` and `4ef701ef62d4…`: the source asks for a transparent background and the test image is rendered on black, so black arrows and labels drawn on it do not show (for `4ef701ef62d4…`, those outside its one filled box).
- Intervals cover diagram variance only, not decoding or training seed.
