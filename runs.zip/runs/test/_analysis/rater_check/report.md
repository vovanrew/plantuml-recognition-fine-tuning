# Human-rater check: report

All numbers descriptive, outside the claim family. Agreement: of the pairs where the metric differs and the rater picked A or B, those where the pick is the answer the metric scores higher; Wilson 95% interval.

## Agreement with the metric

| Rater | Version | Element F1 | Relationship F1 |
|---|---|---|---|
| R1 | v2 | 17/28 = 0.607 [0.424, 0.764]; same 4 (pairs 32) | 45/48 = 0.938 [0.832, 0.979]; same 8 (pairs 56) |
| R1 | v1 | 17/28 = 0.607 [0.424, 0.764]; same 4 (pairs 32) | 43/46 = 0.935 [0.825, 0.978]; same 8 (pairs 54) |
| R2 | v2 | 21/30 = 0.700 [0.521, 0.833]; same 2 (pairs 32) | 45/53 = 0.849 [0.729, 0.921]; same 3 (pairs 56) |
| R2 | v1 | 21/30 = 0.700 [0.521, 0.833]; same 2 (pairs 32) | 43/51 = 0.843 [0.720, 0.918]; same 3 (pairs 54) |

## By the pair's direction (v2)

Agreement with the answer the metric prefers (Element F1 when it differs, otherwise Relationship F1), on the pairs of each direction.

| Rater | Metric prefers | Agreement |
|---|---|---|
| R1 | zero-shot | 2/16 = 0.125 [0.035, 0.360]; same 4 (pairs 20) |
| R1 | fine-tuned | 36/36 = 1.000 [0.904, 1.000]; same 4 (pairs 40) |
| R2 | zero-shot | 5/18 = 0.278 [0.125, 0.509]; same 2 (pairs 20) |
| R2 | fine-tuned | 36/38 = 0.947 [0.827, 0.985]; same 2 (pairs 40) |

## Between the raters

Same answer on 48 of 60 pairs (0.800); Cohen's kappa 0.660 (A / B / about the same).

## Counts by size and by type (v2; agree / against / same)

| Rater | Group | Element F1 | Relationship F1 |
|---|---|---|---|
| R1 | 2B | 7 / 2 / 0 | 17 / 0 / 1 |
| R1 | 9B | 8 / 5 / 0 | 15 / 2 / 2 |
| R1 | 27B | 2 / 4 / 4 | 13 / 1 / 5 |
| R1 | class | 9 / 6 / 3 | 24 / 2 / 5 |
| R1 | sequence | 8 / 5 / 1 | 21 / 1 / 3 |
| R2 | 2B | 7 / 1 / 1 | 17 / 0 / 1 |
| R2 | 9B | 9 / 4 / 0 | 13 / 5 / 1 |
| R2 | 27B | 5 / 4 / 1 | 15 / 3 / 1 |
| R2 | class | 12 / 4 / 2 | 22 / 7 / 2 |
| R2 | sequence | 9 / 5 / 0 | 23 / 1 / 1 |

## v1 and v2

Sample pairs where v1 and v2 prefer different answers: Element F1 0 (none), Relationship F1 2 (P16, P38).

## Pairs where both raters chose against the metric

| Pair | Size | Type | Metric prefers | What differs (written by the author) | Kind |
|---|---|---|---|---|---|
| P01 | 9B | class | zero-shot | Fine-tuned draws one arrow from `DrumCS` to `GameObject` where the original has two (`explosionPrefab`, `ExplosionPlayer`); members and visibility icons match. Zero-shot has both arrows, but labels both `explosionPrefab` and shows each member's visibility as the text `[ ]`. Both answers run the overlapping labels `ExplosionPlayer` and `Explosion_SE` together into one. | Errors the scorer does not count (visibility, labels) |
| P04 | 9B | class | zero-shot | Fine-tuned misspells one interface (`EpiringSession` for `ExpiringSession`) but draws the extends and implements arrows the right way round. Zero-shot spells every name right but reverses most inheritance arrows (e.g. `SessionRepository` inherits from `MapSessionRepository`) and draws the interfaces as classes. | Scores split: one name vs the arrows |
| P13 | 2B | sequence | zero-shot | Fine-tuned has all 15 messages exactly as in the original but leaves out the `TCP_ClientImpl` box, which no message uses. Zero-shot has every box but draws all messages as dashed reply arrows, turns `start()` and `join()` into self-messages on `Thread`, and drops or re-routes about half the messages. | Scores split: unused box vs the messages |
| P30 | 27B | sequence | zero-shot | Fine-tuned has 65 of the 66 messages (the last reply is missing) and keeps the original's three divider lines and destroy marks. Zero-shot has all 66 messages but draws the three phases as frames. | Near-tie on the scores; structure the scorer does not count |
| P31 | 27B | sequence | zero-shot | The same original as P13. Fine-tuned as in P13: every message right, the unused `TCP_ClientImpl` box missing. Zero-shot has every box, but four messages start from the wrong participant (three from `UDP_ClientImpl_03` instead of `UDP_ClientImpl`, the last `join()` from `SpreadCheet` instead of `SearchWindowController`). | Scores split: unused box vs the messages |
| P42 | 27B | sequence | zero-shot | Fine-tuned keeps the original's structure: messages that start each phase come from outside the diagram, the four phases are divider lines, the heartbeats are two-way arrows; but its second NameServer box is labelled `NameServer1`. Zero-shot labels both NameServer boxes correctly but has `producer` send the start messages, draws the phases as frames, makes the heartbeats one-way and adds a title. | Scores split: one box label vs the messages |
| P46 | 27B | class | zero-shot | Fine-tuned keeps the four packages with `controller` inside `gui`, and solid inheritance arrows for the MySQL classes; it misspells `LazyHolderDB` as `LazyfolderDB`, draws the abstract classes and the `DAO` interface as plain classes, and misses the two arrows to `AbstractFactoryDao`. Zero-shot spells every name right but has no `controller` package, draws every inheritance as a dashed implements arrow, adds five arrows the original does not have, and reverses `FAQFacade` → `SessionFacade`. | Scores split: one name vs the arrows |
| P51 | 9B | class | zero-shot | Fine-tuned matches the original (title, `IEnumerable<T>`, members) except that the `Create` arrow is solid instead of dashed. Zero-shot has the dashed arrow but no title, adds a member `T` to `IEnumerable`, and writes the return type as `IE` instead of `IEnumerator`. | Errors the scorer does not count (members, title); one arrow kind |
| P54 | 9B | class | zero-shot | Fine-tuned has the members, visibility and abstract `Metadata` as in the original; its arrows are closer to the original but not all right (the inheritance the right way round, the two links through `Result` and `Run` drawn loosely). Zero-shot has the class names but draws every relation twice (once each way), reverses the two inheritance arrows, shows `Metadata` as a plain class, writes `[C]` / `[A]` as a member line in every class, and changes `#` members to `+`. | Scores split: element count vs the arrows |
| P55 | 9B | sequence | zero-shot | Fine-tuned reproduces the whole diagram (both groups, every message and note) but writes the two participant names as `did:....GS1` and `did:....Manufacturer` instead of `did:...:GS1` and `did:...:Manufacturer`. Zero-shot has the right names but draws a loose graph: the messages are piled on top of each other between the two actors and the notes sit in frames. | The scorer's exact name match: one character |
| P59 | 9B | sequence | zero-shot | The original has two participants both named `Control`. Fine-tuned declares both with the same name, so they merge into one box and `createToken` and its reply become self-messages. Zero-shot adds a line that turns the sequence diagram into a loose graph with three `Control` icons and one left unconnected. | Scores split: one box vs the diagram type |
