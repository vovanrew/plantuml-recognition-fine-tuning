Written after the coding (2026-10-29), from the final codes and the coders' evidence lines. The
sample has one case per run × type × tier × failure class, so its counts (in brackets, cases of
the run's sample) describe the kinds of failure, not how often each occurs; the rates are §1's.

**2B.** Before fine-tuning (16 cases), the sampled failures are mostly the wrong diagram family
(C3, 5). Sequence diagrams are written with class-diagram arrows (`P ..> C : …`) or `interface`
lifelines, and a class diagram with bare arrows renders as a sequence. Then come runaway answers
(C2, 3) that repeat display-only lines until the token limit, syntax errors (C1, 2), missed and
invented relations (S2, 2; S3, 2), one misread name (S4) and one relation-type error (S1, plain
links drawn as `..>`). After fine-tuning (16), misread names lead (S4, 5): `did:....:GS1` with four
dots for three, `EmploysManagement` for `Employes…`, a dropped word, a package subtitle glued onto
the class name. Each one fails every edge that touches the name. Runaway answers (C2, 4) and syntax
errors (C1, 4) follow: a name with parentheses or spaces left unquoted, `activate` after
`deactivate` with no message between. No sampled case is a family confusion.

**9B.** Before fine-tuning (16), runaway answers (C2, 5) and family confusion (C3, 4) lead, with
lifelines written as `rectangle` or the diagram redrawn as packages of components. Relation-type
errors (S1, 2) are plain associations drawn as inheritance and diamonds on the part's side. After
fine-tuning (15), syntax errors lead (C1, 6), each one token on otherwise faithful content: an
unquoted `Foo3()`, `ms-trade` or `mongoose.model()`, a note block closed with `endrnote`, a note
opened before its class. Misread names follow (S4, 3): `Appellant` for `Appelant`, a dropped first
line of a two-line name, a missing space after `:`. Family confusion remains in a new form (C3,
2): class diagrams written as bare `A -> B` lines with no declarations render as sequences.
Relation-type errors (S1, 2) are associations drawn as aggregation (`o->`) and composition for
aggregation.

**27B.** Before fine-tuning (16), syntax errors (C1, 5) and family confusion (C3, 4) lead. The
syntax errors include empty packages without `{}`, an edge ending in a colon, and an invalid
`skinparam` block. The family confusions are participants written as `component` or `partition`,
and a sequence redrawn as a class diagram. Relation-type errors (S1, 2) are aggregation written as
composition and associations as inheritance. After fine-tuning (16), syntax errors still lead (C1,
5): unquoted generics (`DomainRepository<I, T>`), `rnote … endrnote`, `hide empty namespace`, a
`database` without its body. Runaway answers (C2, 3) still occur, looping on a repeated block or
on display-only lines. Family confusion (C3, 2) is the same bare-arrow and class-arrow form as at
the 9B. The rest are misread names (S4, 2), one association drawn as aggregation (S1), one missing
class (S7), one set of package links attached to the classes inside (S2) and one measurement
artifact (M).

**Across sizes.** The zero-shot failures sampled are broken generation (C2) and the wrong diagram
family (C3): 10 and 13 of 48 cases. After fine-tuning they are mostly one syntax slip on faithful
content (C1, 15 of 47) or a misread name (S4, 10 of 47). Runaway answers remain at every size
(9 of 47).

**Relation agreement (§3).**
- On the edges both runs connected, the share drawn with the right relation rises at every size
  and for every relation.
- The rises are largest at the 2B (composition 0.05 → 0.89, aggregation 0.08 → 1.00, dependency
  0.17 → 1.00), where every class relation is below the floor and has points only.
- Among the rows with intervals, composition and aggregation rise most: at the 9B composition 0.34
  → 0.98; at the 27B composition 0.75 → 0.99 and aggregation 0.73 → 0.97. The 9B's aggregation
  (0.38 → 0.97) is points only.
- The intervals of the 27B's dependency and association rows include 0.
- After fine-tuning, every class relation agrees on at least 0.89 of its edges, and orientation
  on the agreeing edges is at least 0.96.
- Zero-shot, the 2B draws 8% and the 9B 26% of the sequence messages as associations or
  dependencies (message agreement 0.92 and 0.74); after fine-tuning none at either size (1.00).

**Separability.** On the stripped answers, a simple rule still guesses the condition with 0.69–0.74
balanced accuracy, mostly from a missing `@enduml` and from directional arrows (`-up-`). The
coders saw the stripped answers, so their blinding was partial.

**Measurement.** One case is a measurement artifact (M). It is a 27B fine-tuned answer whose input
image (key `de434622c1f4…`) is rendered on a black background, so the ground truth's black arrows
and labels do not show. Two other test images have the same defect (Limitations).
