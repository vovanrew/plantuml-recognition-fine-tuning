# Paired bootstrap CIs — zero-shot image→PlantUML benchmark

**Models included: 6/6**

Method: paired percentile bootstrap (2.5/97.5), resample diagrams, shared draws across models; n=1000 resamples, seed=20260614. Cells are `point [2.5th, 97.5th]`. CSR / F1 / type-accuracy on the 0–1 scale (3 dp); chrF++ on its native scale (2 dp). chrF++ **micro** is a corpus statistic with no per-diagram component — reported as a point estimate, no CI.

## Per-model 95% CIs (headline metrics)

| Model | CSR | Element F1 micro (zeros) | Element F1 micro (compiled) | Rel F1 micro (zeros) | Rel F1 micro (compiled) | chrF++ macro (zeros) | chrF++ macro (compiled) | Type acc |
|---|---|---|---|---|---|---|---|---|
| Qwen3.5-2B, zero-shot | 0.191 [0.167, 0.215] | 0.239 [0.205, 0.272] | 0.874 [0.832, 0.912] | 0.110 [0.087, 0.134] | 0.463 [0.391, 0.542] | 11.82 [10.31, 13.45] | 61.90 [59.77, 64.12] | 0.755 [0.702, 0.807] |
| Qwen3.5-2B, fine-tuned | 0.903 [0.884, 0.920] | 0.862 [0.835, 0.887] | 0.955 [0.938, 0.968] | 0.757 [0.722, 0.793] | 0.837 [0.802, 0.871] | 72.14 [70.35, 73.87] | 79.89 [78.87, 81.03] | 0.986 [0.978, 0.991] |
| Qwen3.5-9B, zero-shot | 0.411 [0.381, 0.444] | 0.481 [0.445, 0.520] | 0.871 [0.840, 0.899] | 0.198 [0.169, 0.231] | 0.470 [0.415, 0.526] | 25.83 [23.73, 27.98] | 62.86 [61.15, 64.50] | 0.774 [0.731, 0.812] |
| Qwen3.5-9B, fine-tuned | 0.930 [0.914, 0.945] | 0.911 [0.890, 0.931] | 0.971 [0.960, 0.980] | 0.852 [0.818, 0.883] | 0.906 [0.875, 0.932] | 75.48 [73.78, 77.04] | 81.16 [80.00, 82.34] | 0.987 [0.979, 0.993] |
| Qwen3.5-27B, zero-shot | 0.644 [0.615, 0.673] | 0.713 [0.681, 0.743] | 0.945 [0.926, 0.961] | 0.507 [0.460, 0.552] | 0.729 [0.672, 0.780] | 43.87 [41.65, 46.10] | 68.12 [66.67, 69.65] | 0.889 [0.867, 0.909] |
| Qwen3.5-27B, fine-tuned | 0.957 [0.944, 0.969] | 0.932 [0.913, 0.949] | 0.971 [0.959, 0.981] | 0.865 [0.831, 0.896] | 0.892 [0.858, 0.922] | 78.46 [77.00, 79.89] | 81.98 [80.87, 83.08] | 0.986 [0.977, 0.993] |

chrF++ micro (point estimate, no CI), zeros / compiled:

- **Qwen3.5-2B, zero-shot**: 8.75 / 61.74
- **Qwen3.5-2B, fine-tuned**: 62.60 / 75.80
- **Qwen3.5-9B, zero-shot**: 22.88 / 62.22
- **Qwen3.5-9B, fine-tuned**: 68.59 / 78.04
- **Qwen3.5-27B, zero-shot**: 40.78 / 66.41
- **Qwen3.5-27B, fine-tuned**: 72.43 / 79.88

## Pairwise model-difference CIs

Δ = row model − column model (positive ⇒ the first model scores higher). `excludes 0` flags a CI that does not contain zero (significant at 95%).

### CSR

| Pair (A − B) | Δ | 95% CI | excludes 0 |
|---|---|---|---|
| Qwen3.5-2B, zero-shot − Qwen3.5-2B, fine-tuned | -0.712 | [-0.740, -0.682] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, zero-shot | -0.220 | [-0.258, -0.183] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, fine-tuned | -0.739 | [-0.766, -0.711] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, zero-shot | -0.453 | [-0.489, -0.417] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, fine-tuned | -0.766 | [-0.794, -0.740] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, zero-shot | 0.492 | [0.458, 0.524] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, fine-tuned | -0.027 | [-0.046, -0.007] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, zero-shot | 0.259 | [0.226, 0.291] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, fine-tuned | -0.054 | [-0.073, -0.034] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-9B, fine-tuned | -0.519 | [-0.551, -0.484] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, zero-shot | -0.233 | [-0.271, -0.197] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, fine-tuned | -0.546 | [-0.576, -0.512] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, zero-shot | 0.286 | [0.253, 0.317] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, fine-tuned | -0.027 | [-0.044, -0.010] | **yes** |
| Qwen3.5-27B, zero-shot − Qwen3.5-27B, fine-tuned | -0.313 | [-0.345, -0.282] | **yes** |

### Element F1 micro (zeros)

| Pair (A − B) | Δ | 95% CI | excludes 0 |
|---|---|---|---|
| Qwen3.5-2B, zero-shot − Qwen3.5-2B, fine-tuned | -0.622 | [-0.660, -0.584] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, zero-shot | -0.242 | [-0.289, -0.193] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, fine-tuned | -0.672 | [-0.710, -0.636] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, zero-shot | -0.474 | [-0.517, -0.431] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, fine-tuned | -0.693 | [-0.730, -0.655] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, zero-shot | 0.381 | [0.341, 0.419] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, fine-tuned | -0.050 | [-0.072, -0.026] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, zero-shot | 0.149 | [0.118, 0.180] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, fine-tuned | -0.070 | [-0.093, -0.048] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-9B, fine-tuned | -0.430 | [-0.470, -0.390] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, zero-shot | -0.232 | [-0.274, -0.184] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, fine-tuned | -0.451 | [-0.488, -0.412] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, zero-shot | 0.198 | [0.167, 0.232] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, fine-tuned | -0.021 | [-0.037, -0.006] | **yes** |
| Qwen3.5-27B, zero-shot − Qwen3.5-27B, fine-tuned | -0.219 | [-0.251, -0.190] | **yes** |

### Element F1 micro (compiled)

| Pair (A − B) | Δ | 95% CI | excludes 0 |
|---|---|---|---|
| Qwen3.5-2B, zero-shot − Qwen3.5-2B, fine-tuned | -0.081 | [-0.123, -0.039] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, zero-shot | 0.003 | [-0.042, 0.054] | no |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, fine-tuned | -0.097 | [-0.139, -0.055] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, zero-shot | -0.071 | [-0.114, -0.028] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, fine-tuned | -0.097 | [-0.140, -0.056] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, zero-shot | 0.084 | [0.053, 0.115] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, fine-tuned | -0.016 | [-0.029, -0.005] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, zero-shot | 0.009 | [-0.006, 0.028] | no |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, fine-tuned | -0.016 | [-0.030, -0.003] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-9B, fine-tuned | -0.100 | [-0.131, -0.071] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, zero-shot | -0.074 | [-0.106, -0.042] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, fine-tuned | -0.100 | [-0.132, -0.070] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, zero-shot | 0.026 | [0.009, 0.046] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, fine-tuned | 0.000 | [-0.012, 0.014] | no |
| Qwen3.5-27B, zero-shot − Qwen3.5-27B, fine-tuned | -0.025 | [-0.043, -0.009] | **yes** |

### Rel F1 micro (zeros)

| Pair (A − B) | Δ | 95% CI | excludes 0 |
|---|---|---|---|
| Qwen3.5-2B, zero-shot − Qwen3.5-2B, fine-tuned | -0.647 | [-0.684, -0.605] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, zero-shot | -0.087 | [-0.122, -0.050] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, fine-tuned | -0.742 | [-0.776, -0.705] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, zero-shot | -0.397 | [-0.444, -0.348] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, fine-tuned | -0.755 | [-0.789, -0.715] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, zero-shot | 0.559 | [0.520, 0.602] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, fine-tuned | -0.095 | [-0.124, -0.066] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, zero-shot | 0.250 | [0.209, 0.294] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, fine-tuned | -0.108 | [-0.136, -0.082] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-9B, fine-tuned | -0.654 | [-0.693, -0.613] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, zero-shot | -0.310 | [-0.354, -0.265] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, fine-tuned | -0.667 | [-0.703, -0.627] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, zero-shot | 0.345 | [0.306, 0.389] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, fine-tuned | -0.013 | [-0.036, 0.012] | no |
| Qwen3.5-27B, zero-shot − Qwen3.5-27B, fine-tuned | -0.358 | [-0.399, -0.320] | **yes** |

### Rel F1 micro (compiled)

| Pair (A − B) | Δ | 95% CI | excludes 0 |
|---|---|---|---|
| Qwen3.5-2B, zero-shot − Qwen3.5-2B, fine-tuned | -0.374 | [-0.450, -0.289] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, zero-shot | -0.007 | [-0.098, 0.086] | no |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, fine-tuned | -0.443 | [-0.520, -0.358] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, zero-shot | -0.265 | [-0.354, -0.167] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, fine-tuned | -0.429 | [-0.505, -0.340] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, zero-shot | 0.367 | [0.300, 0.430] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, fine-tuned | -0.069 | [-0.101, -0.042] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, zero-shot | 0.108 | [0.059, 0.162] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, fine-tuned | -0.056 | [-0.087, -0.022] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-9B, fine-tuned | -0.436 | [-0.495, -0.377] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, zero-shot | -0.258 | [-0.326, -0.182] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, fine-tuned | -0.422 | [-0.485, -0.361] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, zero-shot | 0.177 | [0.131, 0.233] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, fine-tuned | 0.014 | [-0.019, 0.045] | no |
| Qwen3.5-27B, zero-shot − Qwen3.5-27B, fine-tuned | -0.164 | [-0.212, -0.121] | **yes** |

### chrF++ macro (zeros)

| Pair (A − B) | Δ | 95% CI | excludes 0 |
|---|---|---|---|
| Qwen3.5-2B, zero-shot − Qwen3.5-2B, fine-tuned | -60.32 | [-62.40, -58.11] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, zero-shot | -14.01 | [-16.53, -11.66] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, fine-tuned | -63.66 | [-65.59, -61.55] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, zero-shot | -32.05 | [-34.59, -29.53] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, fine-tuned | -66.64 | [-68.74, -64.63] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, zero-shot | 46.31 | [44.04, 48.60] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, fine-tuned | -3.34 | [-4.82, -1.83] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, zero-shot | 28.27 | [25.65, 30.56] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, fine-tuned | -6.32 | [-7.84, -4.78] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-9B, fine-tuned | -49.65 | [-51.78, -47.28] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, zero-shot | -18.04 | [-20.51, -15.54] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, fine-tuned | -52.62 | [-54.79, -50.41] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, zero-shot | 31.61 | [29.05, 33.94] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, fine-tuned | -2.98 | [-4.31, -1.78] | **yes** |
| Qwen3.5-27B, zero-shot − Qwen3.5-27B, fine-tuned | -34.59 | [-37.00, -32.09] | **yes** |

### chrF++ macro (compiled)

| Pair (A − B) | Δ | 95% CI | excludes 0 |
|---|---|---|---|
| Qwen3.5-2B, zero-shot − Qwen3.5-2B, fine-tuned | -17.99 | [-20.05, -15.92] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, zero-shot | -0.96 | [-3.52, 1.68] | no |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, fine-tuned | -19.26 | [-21.32, -17.06] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, zero-shot | -6.23 | [-8.61, -3.86] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, fine-tuned | -20.09 | [-22.14, -17.84] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, zero-shot | 17.04 | [15.52, 18.64] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, fine-tuned | -1.27 | [-2.07, -0.42] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, zero-shot | 11.77 | [10.47, 13.19] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, fine-tuned | -2.09 | [-2.78, -1.34] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-9B, fine-tuned | -18.30 | [-20.02, -16.72] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, zero-shot | -5.27 | [-6.76, -3.77] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, fine-tuned | -19.13 | [-20.70, -17.61] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, zero-shot | 13.04 | [11.58, 14.39] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, fine-tuned | -0.82 | [-1.48, -0.14] | **yes** |
| Qwen3.5-27B, zero-shot − Qwen3.5-27B, fine-tuned | -13.86 | [-15.24, -12.48] | **yes** |

### Type acc

| Pair (A − B) | Δ | 95% CI | excludes 0 |
|---|---|---|---|
| Qwen3.5-2B, zero-shot − Qwen3.5-2B, fine-tuned | -0.231 | [-0.285, -0.179] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, zero-shot | -0.019 | [-0.079, 0.048] | no |
| Qwen3.5-2B, zero-shot − Qwen3.5-9B, fine-tuned | -0.232 | [-0.285, -0.178] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, zero-shot | -0.134 | [-0.189, -0.077] | **yes** |
| Qwen3.5-2B, zero-shot − Qwen3.5-27B, fine-tuned | -0.231 | [-0.284, -0.178] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, zero-shot | 0.212 | [0.175, 0.254] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-9B, fine-tuned | -0.001 | [-0.008, 0.007] | no |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, zero-shot | 0.097 | [0.076, 0.118] | **yes** |
| Qwen3.5-2B, fine-tuned − Qwen3.5-27B, fine-tuned | -0.000 | [-0.006, 0.006] | no |
| Qwen3.5-9B, zero-shot − Qwen3.5-9B, fine-tuned | -0.213 | [-0.256, -0.174] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, zero-shot | -0.115 | [-0.158, -0.076] | **yes** |
| Qwen3.5-9B, zero-shot − Qwen3.5-27B, fine-tuned | -0.212 | [-0.254, -0.174] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, zero-shot | 0.098 | [0.076, 0.119] | **yes** |
| Qwen3.5-9B, fine-tuned − Qwen3.5-27B, fine-tuned | 0.001 | [-0.004, 0.006] | no |
| Qwen3.5-27B, zero-shot − Qwen3.5-27B, fine-tuned | -0.097 | [-0.118, -0.077] | **yes** |

## Relationship F1 by relation type — per-model 95% CIs

### Population: zeros_for_failed (micro F1)

| Model | inheritance | composition | aggregation | dependency | association | message |
|---|---|---|---|---|---|---|
| Qwen3.5-2B, zero-shot | 0.076 [0.042, 0.117] | 0.000 [0.000, 0.000] | 0.008 [0.000, 0.027] | 0.013 [0.000, 0.034] | 0.036 [0.014, 0.062] | 0.141 [0.108, 0.173] |
| Qwen3.5-2B, fine-tuned | 0.752 [0.689, 0.810] | 0.604 [0.484, 0.728] | 0.640 [0.521, 0.748] | 0.568 [0.466, 0.657] | 0.545 [0.481, 0.616] | 0.802 [0.755, 0.849] |
| Qwen3.5-9B, zero-shot | 0.381 [0.317, 0.446] | 0.159 [0.076, 0.255] | 0.160 [0.079, 0.264] | 0.223 [0.153, 0.297] | 0.223 [0.174, 0.281] | 0.155 [0.114, 0.205] |
| Qwen3.5-9B, fine-tuned | 0.828 [0.754, 0.892] | 0.723 [0.588, 0.852] | 0.732 [0.626, 0.843] | 0.739 [0.642, 0.820] | 0.686 [0.622, 0.752] | 0.893 [0.849, 0.930] |
| Qwen3.5-27B, zero-shot | 0.665 [0.589, 0.739] | 0.340 [0.225, 0.466] | 0.470 [0.355, 0.589] | 0.535 [0.435, 0.619] | 0.372 [0.304, 0.444] | 0.509 [0.443, 0.566] |
| Qwen3.5-27B, fine-tuned | 0.858 [0.774, 0.927] | 0.767 [0.637, 0.877] | 0.783 [0.680, 0.892] | 0.763 [0.678, 0.839] | 0.702 [0.634, 0.778] | 0.899 [0.856, 0.936] |

### Population: compiled_only (micro F1)

| Model | inheritance | composition | aggregation | dependency | association | message |
|---|---|---|---|---|---|---|
| Qwen3.5-2B, zero-shot | 0.388 [0.229, 0.564] | 0.000 [0.000, 0.000] | 0.154 [0.000, 0.334] | 0.029 [0.000, 0.071] | 0.134 [0.054, 0.232] | 0.605 [0.498, 0.716] |
| Qwen3.5-2B, fine-tuned | 0.866 [0.826, 0.905] | 0.729 [0.629, 0.823] | 0.780 [0.699, 0.853] | 0.644 [0.542, 0.724] | 0.666 [0.603, 0.737] | 0.866 [0.817, 0.911] |
| Qwen3.5-9B, zero-shot | 0.526 [0.448, 0.604] | 0.271 [0.147, 0.420] | 0.253 [0.127, 0.390] | 0.283 [0.199, 0.370] | 0.299 [0.234, 0.380] | 0.707 [0.625, 0.786] |
| Qwen3.5-9B, fine-tuned | 0.903 [0.830, 0.957] | 0.853 [0.743, 0.940] | 0.756 [0.650, 0.867] | 0.806 [0.720, 0.881] | 0.759 [0.697, 0.824] | 0.937 [0.898, 0.968] |
| Qwen3.5-27B, zero-shot | 0.790 [0.706, 0.854] | 0.563 [0.426, 0.686] | 0.578 [0.447, 0.700] | 0.647 [0.551, 0.737] | 0.464 [0.382, 0.548] | 0.790 [0.695, 0.866] |
| Qwen3.5-27B, fine-tuned | 0.893 [0.808, 0.959] | 0.809 [0.671, 0.922] | 0.800 [0.696, 0.914] | 0.808 [0.726, 0.891] | 0.766 [0.695, 0.838] | 0.919 [0.874, 0.956] |

