# Master table — zero-shot image→PlantUML benchmark

**Models included: 6/6** (panel label: main)

Two populations reported side by side as `zeros_for_failed / compiled_only`: `zeros_for_failed` scores all diagrams (non-compiled = 0); `compiled_only` is over compiled cells, with CSR reported separately. chrF++ values in the headline tables are micro (corpus sacrebleu, available at the overall scope only); the macro tables and JSON carry the poolable chrF++ macro for every scope. Type accuracy is the `compiled_only` population by definition.

### Overall (micro)

| Model | CSR | Element F1 | Relationship F1 | chrF++ | Type acc |
|---|---|---|---|---|---|
| Qwen3.5-2B, zero-shot | 19.1% | 0.239 / 0.874 | 0.110 / 0.463 | 8.75 / 61.74 | 0.755 |
| Qwen3.5-2B, fine-tuned | 90.3% | 0.862 / 0.955 | 0.757 / 0.837 | 62.60 / 75.80 | 0.986 |
| Qwen3.5-9B, zero-shot | 41.1% | 0.481 / 0.871 | 0.198 / 0.470 | 22.88 / 62.22 | 0.774 |
| Qwen3.5-9B, fine-tuned | 93.0% | 0.911 / 0.971 | 0.852 / 0.906 | 68.59 / 78.04 | 0.987 |
| Qwen3.5-27B, zero-shot | 64.4% | 0.713 / 0.945 | 0.507 / 0.729 | 40.78 / 66.41 | 0.889 |
| Qwen3.5-27B, fine-tuned | 95.7% | 0.932 / 0.971 | 0.865 / 0.892 | 72.43 / 79.88 | 0.986 |

### Overall (macro)

| Model | CSR | Element F1 | Relationship F1 | chrF++ | Type acc |
|---|---|---|---|---|---|
| Qwen3.5-2B, zero-shot | 19.1% | 0.169 / 0.879 | 0.174 / 0.494 | 11.82 / 61.90 | 0.755 |
| Qwen3.5-2B, fine-tuned | 90.3% | 0.872 / 0.966 | 0.820 / 0.901 | 72.14 / 79.89 | 0.986 |
| Qwen3.5-9B, zero-shot | 41.1% | 0.365 / 0.888 | 0.265 / 0.536 | 25.83 / 62.86 | 0.774 |
| Qwen3.5-9B, fine-tuned | 93.0% | 0.911 / 0.979 | 0.887 / 0.945 | 75.48 / 81.16 | 0.987 |
| Qwen3.5-27B, zero-shot | 64.4% | 0.619 / 0.958 | 0.533 / 0.800 | 43.87 / 68.12 | 0.889 |
| Qwen3.5-27B, fine-tuned | 95.7% | 0.942 / 0.984 | 0.914 / 0.953 | 78.46 / 81.98 | 0.986 |

### Population gap (compiled-only − all-1000, micro)

The `compiled_only` minus `zeros_for_failed` gap per metric — the headline measure of how much a model's apparent quality rests on selective failure. A model that drops/times out on its hard diagrams is graded on an easier subset, so its `compiled_only` score runs far above its honest all-1000 score; a large gap is that fingerprint (it tracks the answer rate / CSR).

| Model | CSR | Element F1 (all → cmp, Δ) | Relationship F1 (all → cmp, Δ) | chrF++ (all → cmp, Δ) |
|---|---|---|---|---|
| Qwen3.5-2B, zero-shot | 19.1% | 0.239 → 0.874 (+0.635) | 0.110 → 0.463 (+0.353) | 8.75 → 61.74 (+53.00) |
| Qwen3.5-2B, fine-tuned | 90.3% | 0.862 → 0.955 (+0.093) | 0.757 → 0.837 (+0.080) | 62.60 → 75.80 (+13.20) |
| Qwen3.5-9B, zero-shot | 41.1% | 0.481 → 0.871 (+0.390) | 0.198 → 0.470 (+0.273) | 22.88 → 62.22 (+39.34) |
| Qwen3.5-9B, fine-tuned | 93.0% | 0.911 → 0.971 (+0.060) | 0.852 → 0.906 (+0.054) | 68.59 → 78.04 (+9.45) |
| Qwen3.5-27B, zero-shot | 64.4% | 0.713 → 0.945 (+0.232) | 0.507 → 0.729 (+0.221) | 40.78 → 66.41 (+25.62) |
| Qwen3.5-27B, fine-tuned | 95.7% | 0.932 → 0.971 (+0.039) | 0.865 → 0.892 (+0.027) | 72.43 → 79.88 (+7.45) |

### Relationship F1 by relation type (read-through)

**Qwen3.5-2B, zero-shot** — F1 (zeros_for_failed / compiled_only), support_gt:

| Relation | F1 (z / c) | support_gt (z / c) |
|---|---|---|
| inheritance | 0.076 / 0.388 | 940 / 119 |
| composition | 0.000 / 0.000 | 300 / 28 |
| aggregation | 0.008 / 0.154 | 244 / 12 |
| dependency | 0.013 / 0.029 | 375 / 55 |
| association | 0.036 / 0.134 | 862 / 99 |
| message | 0.141 / 0.605 | 6544 / 874 |

**Qwen3.5-2B, fine-tuned** — F1 (zeros_for_failed / compiled_only), support_gt:

| Relation | F1 (z / c) | support_gt (z / c) |
|---|---|---|
| inheritance | 0.752 / 0.866 | 940 / 716 |
| composition | 0.604 / 0.729 | 300 / 216 |
| aggregation | 0.640 / 0.780 | 244 / 172 |
| dependency | 0.568 / 0.644 | 375 / 301 |
| association | 0.545 / 0.666 | 862 / 606 |
| message | 0.802 / 0.866 | 6544 / 5656 |

**Qwen3.5-9B, zero-shot** — F1 (zeros_for_failed / compiled_only), support_gt:

| Relation | F1 (z / c) | support_gt (z / c) |
|---|---|---|
| inheritance | 0.381 / 0.526 | 940 / 541 |
| composition | 0.159 / 0.271 | 300 / 150 |
| aggregation | 0.160 / 0.253 | 244 / 134 |
| dependency | 0.223 / 0.283 | 375 / 175 |
| association | 0.223 / 0.299 | 862 / 440 |
| message | 0.155 / 0.707 | 6544 / 906 |

**Qwen3.5-9B, fine-tuned** — F1 (zeros_for_failed / compiled_only), support_gt:

| Relation | F1 (z / c) | support_gt (z / c) |
|---|---|---|
| inheritance | 0.828 / 0.903 | 940 / 796 |
| composition | 0.723 / 0.853 | 300 / 220 |
| aggregation | 0.732 / 0.756 | 244 / 228 |
| dependency | 0.739 / 0.806 | 375 / 317 |
| association | 0.686 / 0.759 | 862 / 711 |
| message | 0.893 / 0.937 | 6544 / 5952 |

**Qwen3.5-27B, zero-shot** — F1 (zeros_for_failed / compiled_only), support_gt:

| Relation | F1 (z / c) | support_gt (z / c) |
|---|---|---|
| inheritance | 0.665 / 0.790 | 940 / 682 |
| composition | 0.340 / 0.563 | 300 / 134 |
| aggregation | 0.470 / 0.578 | 244 / 172 |
| dependency | 0.535 / 0.647 | 375 / 255 |
| association | 0.372 / 0.464 | 862 / 557 |
| message | 0.509 / 0.790 | 6544 / 3084 |

**Qwen3.5-27B, fine-tuned** — F1 (zeros_for_failed / compiled_only), support_gt:

| Relation | F1 (z / c) | support_gt (z / c) |
|---|---|---|
| inheritance | 0.858 / 0.893 | 940 / 870 |
| composition | 0.767 / 0.809 | 300 / 272 |
| aggregation | 0.783 / 0.800 | 244 / 233 |
| dependency | 0.763 / 0.808 | 375 / 335 |
| association | 0.702 / 0.766 | 862 / 731 |
| message | 0.899 / 0.919 | 6544 / 6271 |

### Type accuracy by GT entity type (compiled_only, read-through)

**Qwen3.5-2B, zero-shot** — pooled accuracy 0.755 (matched 799, excluded 0, denominator 799):

| GT type | support | accuracy |
|---|---|---|
| abstract_class | 20 | 0.000 |
| actor | 48 | 0.146 |
| boundary | 13 | 0.000 |
| class | 326 | 0.939 |
| collections | 1 | 0.000 |
| control | 13 | 0.000 |
| database | 15 | 0.000 |
| entity | 9 | 0.000 |
| enum | 11 | 0.000 |
| interface | 32 | 0.188 |
| participant | 309 | 0.919 |
| queue | 2 | 0.000 |

**Qwen3.5-2B, fine-tuned** — pooled accuracy 0.986 (matched 4498, excluded 73, denominator 4425):

| GT type | support | accuracy |
|---|---|---|
| abstract_class | 122 | 0.885 |
| actor | 262 | 0.992 |
| annotation | 1 | 1.000 |
| boundary | 58 | 0.983 |
| class | 1818 | 0.996 |
| collections | 27 | 0.889 |
| control | 67 | 1.000 |
| database | 107 | 0.991 |
| entity | 81 | 0.840 |
| enum | 51 | 0.922 |
| interface | 192 | 0.943 |
| object | 7 | 0.000 |
| participant | 1624 | 1.000 |
| queue | 8 | 0.875 |

**Qwen3.5-9B, zero-shot** — pooled accuracy 0.774 (matched 1959, excluded 29, denominator 1930):

| GT type | support | accuracy |
|---|---|---|
| abstract_class | 89 | 0.022 |
| actor | 72 | 0.486 |
| annotation | 1 | 0.000 |
| boundary | 11 | 0.000 |
| class | 1265 | 0.953 |
| collections | 5 | 0.000 |
| control | 15 | 0.000 |
| database | 20 | 0.400 |
| entity | 27 | 0.037 |
| enum | 28 | 0.071 |
| interface | 149 | 0.557 |
| participant | 248 | 0.629 |

**Qwen3.5-9B, fine-tuned** — pooled accuracy 0.987 (matched 4911, excluded 59, denominator 4852):

| GT type | support | accuracy |
|---|---|---|
| abstract_class | 134 | 0.881 |
| actor | 271 | 0.996 |
| annotation | 1 | 1.000 |
| boundary | 66 | 0.970 |
| class | 2062 | 0.992 |
| collections | 30 | 0.967 |
| control | 72 | 0.986 |
| database | 111 | 1.000 |
| entity | 95 | 0.874 |
| enum | 57 | 0.982 |
| interface | 204 | 0.966 |
| object | 7 | 0.143 |
| participant | 1735 | 0.999 |
| queue | 7 | 1.000 |

**Qwen3.5-27B, zero-shot** — pooled accuracy 0.889 (matched 3294, excluded 42, denominator 3252):

| GT type | support | accuracy |
|---|---|---|
| abstract_class | 123 | 0.480 |
| actor | 115 | 0.826 |
| annotation | 1 | 0.000 |
| boundary | 44 | 0.227 |
| class | 1679 | 0.985 |
| collections | 13 | 0.000 |
| control | 36 | 0.139 |
| database | 29 | 0.759 |
| entity | 62 | 0.339 |
| enum | 31 | 0.387 |
| interface | 168 | 0.857 |
| participant | 947 | 0.916 |
| queue | 4 | 0.250 |

**Qwen3.5-27B, fine-tuned** — pooled accuracy 0.986 (matched 5140, excluded 78, denominator 5062):

| GT type | support | accuracy |
|---|---|---|
| abstract_class | 135 | 0.911 |
| actor | 276 | 1.000 |
| annotation | 1 | 1.000 |
| boundary | 67 | 1.000 |
| class | 2173 | 0.991 |
| collections | 30 | 0.967 |
| control | 72 | 1.000 |
| database | 112 | 1.000 |
| entity | 104 | 0.808 |
| enum | 58 | 1.000 |
| interface | 218 | 0.954 |
| object | 7 | 0.143 |
| participant | 1801 | 0.998 |
| queue | 8 | 1.000 |

## By diagram type

### Type: class (micro)

| Model | CSR | Element F1 | Relationship F1 | chrF++ | Type acc |
|---|---|---|---|---|---|
| Qwen3.5-2B, zero-shot | 19.8% | 0.220 / 0.887 | 0.040 / 0.175 | — / — | 0.802 |
| Qwen3.5-2B, fine-tuned | 88.2% | 0.832 / 0.958 | 0.638 / 0.754 | — / — | 0.976 |
| Qwen3.5-9B, zero-shot | 62.8% | 0.627 / 0.877 | 0.284 / 0.402 | — / — | 0.834 |
| Qwen3.5-9B, fine-tuned | 91.0% | 0.888 / 0.965 | 0.749 / 0.822 | — / — | 0.978 |
| Qwen3.5-27B, zero-shot | 78.2% | 0.777 / 0.949 | 0.522 / 0.657 | — / — | 0.928 |
| Qwen3.5-27B, fine-tuned | 93.8% | 0.914 / 0.967 | 0.778 / 0.823 | — / — | 0.975 |

### Type: sequence (micro)

| Model | CSR | Element F1 | Relationship F1 | chrF++ | Type acc |
|---|---|---|---|---|---|
| Qwen3.5-2B, zero-shot | 18.4% | 0.262 / 0.862 | 0.140 / 0.579 | — / — | 0.710 |
| Qwen3.5-2B, fine-tuned | 92.4% | 0.896 / 0.951 | 0.803 / 0.866 | — / — | 0.995 |
| Qwen3.5-9B, zero-shot | 19.4% | 0.244 / 0.848 | 0.148 / 0.580 | — / — | 0.528 |
| Qwen3.5-9B, fine-tuned | 95.0% | 0.939 / 0.977 | 0.894 / 0.938 | — / — | 0.996 |
| Qwen3.5-27B, zero-shot | 50.6% | 0.626 / 0.939 | 0.501 / 0.769 | — / — | 0.823 |
| Qwen3.5-27B, fine-tuned | 97.6% | 0.953 / 0.975 | 0.900 / 0.920 | — / — | 0.998 |

## By tier

### Tier 1 (micro)

| Model | CSR | Element F1 | Relationship F1 | chrF++ | Type acc |
|---|---|---|---|---|---|
| Qwen3.5-2B, zero-shot | 32.0% | 0.456 / 0.853 | 0.350 / 0.635 | — / — | 0.789 |
| Qwen3.5-2B, fine-tuned | 97.2% | 0.964 / 0.974 | 0.948 / 0.955 | — / — | 0.989 |
| Qwen3.5-9B, zero-shot | 48.8% | 0.554 / 0.851 | 0.228 / 0.403 | — / — | 0.691 |
| Qwen3.5-9B, fine-tuned | 94.8% | 0.965 / 0.988 | 0.957 / 0.975 | — / — | 0.988 |
| Qwen3.5-27B, zero-shot | 74.0% | 0.806 / 0.957 | 0.697 / 0.841 | — / — | 0.875 |
| Qwen3.5-27B, fine-tuned | 97.6% | 0.984 / 0.993 | 0.979 / 0.983 | — / — | 0.988 |

### Tier 2 (micro)

| Model | CSR | Element F1 | Relationship F1 | chrF++ | Type acc |
|---|---|---|---|---|---|
| Qwen3.5-2B, zero-shot | 21.2% | 0.312 / 0.876 | 0.186 / 0.525 | — / — | 0.769 |
| Qwen3.5-2B, fine-tuned | 93.2% | 0.953 / 0.983 | 0.927 / 0.951 | — / — | 0.994 |
| Qwen3.5-9B, zero-shot | 42.4% | 0.524 / 0.856 | 0.269 / 0.522 | — / — | 0.759 |
| Qwen3.5-9B, fine-tuned | 96.0% | 0.981 / 0.996 | 0.973 / 0.982 | — / — | 0.983 |
| Qwen3.5-27B, zero-shot | 70.0% | 0.800 / 0.976 | 0.661 / 0.817 | — / — | 0.860 |
| Qwen3.5-27B, fine-tuned | 98.4% | 0.986 / 0.993 | 0.969 / 0.977 | — / — | 0.985 |

### Tier 3 (micro)

| Model | CSR | Element F1 | Relationship F1 | chrF++ | Type acc |
|---|---|---|---|---|---|
| Qwen3.5-2B, zero-shot | 17.2% | 0.284 / 0.920 | 0.131 / 0.446 | — / — | 0.672 |
| Qwen3.5-2B, fine-tuned | 92.0% | 0.917 / 0.961 | 0.872 / 0.911 | — / — | 0.988 |
| Qwen3.5-9B, zero-shot | 42.0% | 0.516 / 0.861 | 0.245 / 0.520 | — / — | 0.789 |
| Qwen3.5-9B, fine-tuned | 95.2% | 0.946 / 0.970 | 0.907 / 0.938 | — / — | 0.990 |
| Qwen3.5-27B, zero-shot | 59.6% | 0.733 / 0.964 | 0.546 / 0.800 | — / — | 0.890 |
| Qwen3.5-27B, fine-tuned | 96.4% | 0.957 / 0.975 | 0.953 / 0.964 | — / — | 0.992 |

### Tier 4 (micro)

| Model | CSR | Element F1 | Relationship F1 | chrF++ | Type acc |
|---|---|---|---|---|---|
| Qwen3.5-2B, zero-shot | 6.0% | 0.095 / 0.830 | 0.024 / 0.231 | — / — | 0.827 |
| Qwen3.5-2B, fine-tuned | 78.8% | 0.745 / 0.925 | 0.604 / 0.721 | — / — | 0.976 |
| Qwen3.5-9B, zero-shot | 31.2% | 0.412 / 0.898 | 0.143 / 0.427 | — / — | 0.807 |
| Qwen3.5-9B, fine-tuned | 86.0% | 0.839 / 0.953 | 0.768 / 0.850 | — / — | 0.985 |
| Qwen3.5-27B, zero-shot | 54.0% | 0.630 / 0.910 | 0.404 / 0.627 | — / — | 0.910 |
| Qwen3.5-27B, fine-tuned | 90.4% | 0.876 / 0.950 | 0.772 / 0.813 | — / — | 0.982 |

